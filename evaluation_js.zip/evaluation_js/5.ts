interface TransactionService{
    public pocessTransaction().boolean{
        
    }
}