class Branch{
    constructor(
        public bname:string, 
        public location:string,
        public bcode:number,
    ){}
}
let Branch = new Branch()