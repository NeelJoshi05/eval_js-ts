class InvalidAccountException extends Error{
    constructor(message){
        super(message);
        this.name="InvalidAccountException";
    }

account(status){
    try {
        if (status){
            console.log("valid");
        }else{
            throw new InvalidAccountException
        }
    } catch (error) {
        console.log(error);
    }
}
}
let ob = new InvalidAccountException;
ob.account(1);
