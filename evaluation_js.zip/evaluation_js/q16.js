function balance(status){
    if (status){
        console.log
    }
}