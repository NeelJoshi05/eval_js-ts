function finally_block(update){
    try{
        if(!update){
            throw new error
        }
    }catch(error){
        console.log(error.message);
    }finally{
        console.log("records are updated");
    }
} 