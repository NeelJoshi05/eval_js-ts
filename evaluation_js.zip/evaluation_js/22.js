let increaseaccountbalance = function (account,balance){
    return account.map((account)=> account+balance);
}
console.log(increaseaccountbalance);


