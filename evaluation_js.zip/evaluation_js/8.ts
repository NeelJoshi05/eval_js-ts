class CustomerSupport{
    constructor(
        public name:string,
        public empid: number,
        
    ){}
    

}