function findtopcutomer(account){
    let accountfiltered = acoount.sort((a,b)=>a.count-b.count);
    return accountfiltered.pop();
}

console.log
