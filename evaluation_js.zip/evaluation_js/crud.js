const db=require('./db.js');

function addCustomer(id,name,address){
    
}